Group members’ names: Dat Tien Nguyen     ID: nguy5079@umn.edu

• How to compile and run your program:
    Go to the Game.class file and compile the file by using javac Game.java, then type java Game to run the game
• Additional features that you implemented (if applicable):
    ask user again if they choose the cell that contain no piece or if the cell is not in the board
• Any known bugs or defects in the program:
    This game handle almost every single miss type from player except 1 thing that you have to
    type the right format when you are ask to choose the move ([start row] [start column] [end row] [end column])
    if you want to move the piece from (0,0) to (2,2) then type 0 0 2 2. Otherwise, the program will
    throw an exception since the variable to hold the input is integer, and if you type string then it will crash.



“I certify that the information contained in this README
file is complete and accurate. I have both read and followed the course policies
in the ‘Academic Integrity - Course Policy’ section of the course syllabus.”

Dat Nguyen